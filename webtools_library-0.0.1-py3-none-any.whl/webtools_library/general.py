import os
import csv
import json
import logging

from collections import Counter

def get_logger(user_id: str="", *, level_error: bool=False, file_logs: bool=True, **kwargs):
    fmt = logging.Formatter(f"%(asctime)s %(levelname)s: %(pathname)s:%(lineno)s: %(message)s")

    logger = logging.getLogger()
    if level_error:
        level = logging.ERROR
    else:
        level = logging.INFO
    logger.setLevel(level)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(fmt)
    console_handler.setLevel(level)
    logger.addHandler(console_handler)
    if file_logs:
        os.makedirs("logs", exist_ok=True)
        for l in ["info", "error"]:
            if level_error and l=="info":
                continue

            f = f"{l}.log"
            if user_id: f = f"{user_id}_{f}"
            f = f"logs/{f}"
            h = logging.FileHandler(f, "a")
            h.setLevel(getattr(logging, l.upper()))
            h.setFormatter(fmt)
            logger.addHandler(h)
    return logger

def csv_to_json(csv_f, json_f: str="", delimiter: str=","):
    """
        Expects the first row to contain the labels of the columns
    """
    if not json_f:
        json_f = os.path.splitext(csv_f)[0] + ".json"

    json_d = []
    with open(csv_f, 'r') as f:
        content = csv.reader(f, delimiter=delimiter)
    
        for i, row in enumerate(content):
            row = [ r.strip() for r in row ]
            if i==0:
                keys = row
                continue
            
            d = {}
            for i, k in enumerate(keys):
                 d[k] = row[i]
            json_d.append(d)
    
    json.dump(json_d, open(json_f, 'w'), indent=4)

    
def json_to_csv(json_f: str, csv_f: str="", delimiter: str=","):
    if not csv_f:
        csv_f = os.path.splitext(csv_f)[0] + ".csv"
    
    with open(json_f, 'r') as json_file:
        data = json.load(json_file)
    
    with open(csv_f, 'w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=delimiter)
        
        if data:
            header = data[0].keys()
            csv_writer.writerow(header)
            for row in data:
                csv_writer.writerow(row.values())


def save_to_file(data: any, file: str, f_type: str, *, overwrite: bool=True, mode="w"):
    f_type = f_type.lower()
    
    assert not(not overwrite and os.path.exists(file)), "File already exists."

    if f_type=="json":
        json.dump(data, open(file, mode), indent=4)

    elif f_type=="csv":
        with open(file, mode, newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(data)
        
    elif f_type=="txt":
        with open(file, mode) as f:
            f.write(data)
        
    else:
        assert False, "unsupported f_type"


def read_file(file: str, f_type: str, *, mode: str="r"):
    f_type = f_type.lower()
    
    assert os.path.exists(file), "File does not exist."

    if f_type == "json":
        with open(file, mode) as f:
            return json.load(f)
    
    elif f_type == "csv":
        with open(file, mode, newline='') as csvfile:
            reader = csv.reader(csvfile)
            return list(reader)
    
    elif f_type == "txt":
        with open(file, mode) as f:
            return f.read()
    
    else:
        raise ValueError("Unsupported file type")


def compress_list_of_dicts(l: list):
    result = dict(Counter())
    for d in l:
        result.update(d)
    return result


class RaiseError:
    def __init__(self, msg: str, type_: type, logger: logging.Logger):
        logger.error(msg)
        raise type_(msg)
