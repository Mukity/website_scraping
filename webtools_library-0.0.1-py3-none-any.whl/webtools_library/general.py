import os
import csv
import json
import logging

from collections import Counter

def get_logger(fname: str, user_id: str="", level_error: bool=False):
    level = "info"
    fmt = f"%(asctime)s, %(levelname)s: %(pathname)s-line_no:%(lineno)s"
    eh = logging.FileHandler(f"{user_id}_{fname}_error.log", "a")
    eh.setLevel(logging.ERROR)
    eh.setFormatter(fmt)
    if level_error:
        level = "error"
    else:
        ih = logging.FileHandler(f"{user_id}_{fname}_info.log", "a")
        ih.setLevel(logging.INFO)
        ih.setFormatter(fmt)
    
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format=fmt
    )
    return logging.getLogger()


def csv_to_json(csv_f, json_f: str="", delimiter: str=","):
    """
        Expects the first row to contain the labels of the columns
    """
    if not json_f:
        json_f = os.path.splitext(csv_f)[0] + ".json"

    json_d = []
    with open(csv_f, 'r') as f:
        content = csv.reader(f, delimiter=delimiter)
    
        for i, row in enumerate(content):
            row = [ r.strip() for r in row ]
            if i==0:
                keys = row
                continue
            
            d = {}
            for i, k in enumerate(keys):
                 d[k] = row[i]
            json_d.append(d)
    
    json.dump(json_d, open(json_f, 'w'), indent=4)

    
def json_to_csv(json_f: str, csv_f: str="", delimiter: str=","):
    if not csv_f:
        csv_f = os.path.splitext(csv_f)[0] + ".csv"
    
    with open(json_f, 'r') as json_file:
        data = json.load(json_file)
    
    with open(csv_f, 'w', newline='') as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=delimiter)
        
        if data:
            header = data[0].keys()
            csv_writer.writerow(header)
            for row in data:
                csv_writer.writerow(row.values())


def data_to_file(data: any, file: str, f_type: str, *, overwrite: bool=True, mode="w"):
    f_type = f_type.lower()
    
    assert not(overwrite and os.path.exists(file)), "File already exists."

    if f_type=="json":
        json.dump(data, open(file, mode), indent=4)

    elif f_type=="csv":
        with open(file, mode, newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(data)
        
    elif f_type=="txt":
        with open(file, mode) as f:
            f.write(data)
        
    else:
        assert False, "unsupported f_type"


def file_to_data(file: str, f_type: str, *, mode: str="r"):
    f_type = f_type.lower()
    
    assert os.path.exists(file), "File does not exist."

    if f_type == "json":
        with open(file, mode) as f:
            return json.load(f)
    
    elif f_type == "csv":
        with open(file, mode, newline='') as csvfile:
            reader = csv.reader(csvfile)
            return list(reader)
    
    elif f_type == "txt":
        with open(file, mode) as f:
            return f.read()
    
    else:
        raise ValueError("Unsupported file type")


def compress_list_of_dicts(l: list):
    result = dict(Counter())
    for d in l:
        result.update(d)
    return result


class RaiseError:
    def __init__(self, msg: str, type_: type, logger: logging.Logger):
        logger.error(msg)
        raise type_(msg)
